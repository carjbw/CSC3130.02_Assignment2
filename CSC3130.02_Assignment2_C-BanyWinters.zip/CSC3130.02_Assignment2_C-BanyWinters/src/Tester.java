import javax.swing.*;
import java.util.Random;
public class Tester {
    // -----CONSTRUCTOR-----
    public Tester(SortingAlgorithm sa, int inputType) {
        this.sa = sa;
        this.inputType = inputType;
    }

    // -----VARIABLES-----
    SortingAlgorithm sa;
    int inputType; // 0 = random | 1 = 10-sorted
    Random random = new Random();
    boolean sortSuccess;

    // -----METHODS-----
    /*
    Perform a single test of the sorting algorithm using an array of the given size and record how long it takes
        to perform the sort.
        @param int size = the size of the array being passed to the sorting algorithm
        @return double = the time it takes to perform the sort
     */
    private double singleTest(int size) {
        // Generate an input array of given size
        int[] array = getArray(size);
        // Time how long it takes to run the sorting algorithm
        double startTime = System.currentTimeMillis(); // Start timer
        int[] sortedArray = sa.sort(array); // Perform sort
        double endTime = System.currentTimeMillis(); // End timer

        // Use return of sort() to determine whether values are actually sorted
        updateSortSuccess(sortedArray);
        // Return the time elapsed during sort()
        return (endTime - startTime);
    }
    /*
    Test the sorting algorithm by making n calls to singleTest() where n is the given number of iterations,
        passing the given input size to singleTest(). Print to the console the size of the array sorted and the
        average time it took to perform the sort. Print to the console a confirmation that the elements were
        successfully sorted.
        @param int iterations = the number of times the sorting algorithm will be run
        @param int size = the size of the input array that will be sorted
     */
    public void test(int iterations, int size) {
        double sum = 0;
        // Sum together the time it takes to perform all iterations
        for(int i = 0; i < iterations; i++) {
            sum += singleTest(size);
        }
        double avg = (sum / size); // Get the average performance time from the sum
        // Print report to the console
        System.out.println("Sorted " + size + " elements in " + avg + " ms (avg)");
        System.out.println(getSortSuccessString());
    }

    private int[] getArray(int size) {
        int[] a = new int[size];
        if(inputType == 1) {
            return (new KSort().generateKSort(generateRandom(a)));
        }
        else {
            return generateRandom(a);
        }
    }

    private int[] generateRandom(int[] a) {
        for(int i = 0; i < a.length; i++) {
            a[i] = random.nextInt();
        }
        return a;
    }

    /*
    Determine whether a given array of ints is sorted.
    @param int[] a = the array being tested
    @return boolean = true if sorted, false otherwise
     */
    private boolean isSorted(int[] a) {
        /*
        Starting at the second element in the array (a[1]), check to see if this element (a[i]) is less than
            the element directly preceding it (a[i-1]).
            If this is the case, then the array is NOT sorted.
            Else (assuming the loop has checked all elements), the array IS sorted.
         */
        for(int i = 1; i < a.length; i++) {
            if(a[i] < a[i-1]) {
                return false;
            }
        }
        return true;
    }
    /*
    Update the value of the boolean variable sortSuccess depending on the result of passing the given array
        to the isSorted() method.
        @param int[] a = the array being checked
     */
    private void updateSortSuccess(int[] a) {
        sortSuccess = isSorted(a);
    }
    /*
    Get a String that acts as a message informing the user whether the sorting algorithm successfully sorted
        an array, given the current value of the sortSuccess variable.
        @return String = a message that informs the user of either a successful or unsuccessful sort
     */
    private String getSortSuccessString() {
        if(!sortSuccess) {
            return "    Elements were NOT successfully sorted";
        }
        else {
            return "    Elements were successfully sorted";
        }
    }
}
