public class BubbleSort implements SortingAlgorithm {
    @Override
    public int[] sort(int[] input) {
        int n = input.length;
        int tmp;
        for(int i = 0; i < (n-1); i++) {
            for(int j = 0; j < (n - 1 - i); j++) {
                if(input[j+1] < input[j]) {
                    tmp = input[j];
                    input[j] = input[j+1];
                    input[j+1] = tmp;
                }
            }
        }
        return input;
    }
}
