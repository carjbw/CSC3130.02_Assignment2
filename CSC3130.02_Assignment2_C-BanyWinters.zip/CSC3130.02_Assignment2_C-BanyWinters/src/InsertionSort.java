public class InsertionSort implements SortingAlgorithm{
    @Override
    public int[] sort(int[] input) {
        for(int p = 1; p < input.length; ++p) {
            int tmp = input[p];
            int j;
            for(j = p; (j > 0) && (tmp < input[j-1]); j--) {
                input[j] = input[j-1];
            }
            input[j] = tmp;
        }
        return input;
    }
}
