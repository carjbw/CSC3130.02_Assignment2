public interface SortingAlgorithm {
    int[] sort(int[] input);
}
