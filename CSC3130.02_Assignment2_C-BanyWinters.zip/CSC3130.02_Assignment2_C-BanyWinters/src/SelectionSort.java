public class SelectionSort implements SortingAlgorithm {
    @Override
    public int[] sort(int[] input) {
        int n = input.length;
        for(int i = 0; i < n; i++) {
            int minIndex = i;
            for(int j = i + 1; j < n; j++) {
                if(input[j] < input[minIndex]) {
                    minIndex = j;
                }
            }
            int tmp = input[minIndex];
            input[minIndex] = input[i];
            input[i] = tmp;
        }
        return input;
    }
}
