public class KSort {
    int k = 10;
    public int[] generateKSort(int[] a) {
        int[] sorted = (new ShellSort().sort(a));
        for(int i = 0; i < a.length; i++) {
            for(int j = 0; j < sorted.length; j++) {
                if(a[i] == sorted[j]) { // found match in sorted
                    if(i > j+k || i < j-k) {
                        // swap a[i] with a[j]
                        int tmp = a[j];
                        a[j] = a[i];
                        a[i] = tmp;
                    }
                }
            }
        }
        return a;
    }
}
